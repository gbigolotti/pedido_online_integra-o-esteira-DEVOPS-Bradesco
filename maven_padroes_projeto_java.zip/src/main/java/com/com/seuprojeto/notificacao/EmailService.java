package com.seuprojeto.notificacao;

public class EmailService {
    public void enviar(String mensagem) {
        System.out.println("Enviando email: " + mensagem);
    }
}