package com.seuprojeto.pedido;

import com.seuprojeto.frete.FreteStrategy;

public class PedidoBuilder {
    private String produto;
    private int quantidade;
    private double valor;
    private FreteStrategy frete;

    public PedidoBuilder comProduto(String produto) {
        this.produto = produto;
        return this;
    }

    public PedidoBuilder comQuantidade(int quantidade) {
        this.quantidade = quantidade;
        return this;
    }

    public PedidoBuilder comValor(double valor) {
        this.valor = valor;
        return this;
    }

    public PedidoBuilder comFrete(FreteStrategy frete) {
        this.frete = frete;
        return this;
    }

    public Pedido build() {
        return new Pedido(produto, quantidade, valor, frete);
    }
}