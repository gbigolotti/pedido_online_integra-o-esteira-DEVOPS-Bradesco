package com.seuprojeto.frete;

public class CorreiosFrete implements FreteStrategy {
    @Override
    public double calcularFrete() {
        return 20.0;
    }
}