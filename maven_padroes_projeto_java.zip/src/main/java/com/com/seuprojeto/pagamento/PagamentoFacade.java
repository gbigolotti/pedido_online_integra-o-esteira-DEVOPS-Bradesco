package com.seuprojeto.pagamento;

import com.seuprojeto.pedido.Pedido;

public class PagamentoFacade {
    public static void processarPagamento(Pedido pedido) {
        System.out.println("Pagamento processado via PayPal.");
    }
}