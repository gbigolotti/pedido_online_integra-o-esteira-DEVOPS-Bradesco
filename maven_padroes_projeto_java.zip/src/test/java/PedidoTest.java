import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PedidoTest {

    @Test
    public void testCriacaoPedido() {
        assertTrue(true, "Teste inicial passando");
    }
}
