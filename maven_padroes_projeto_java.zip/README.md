# Projeto Java com Padrões de Projeto

Implementa Builder, Strategy, Facade e um exemplo de notificação Observer-like.