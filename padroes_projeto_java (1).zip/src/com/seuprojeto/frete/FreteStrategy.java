package com.seuprojeto.frete;

public interface FreteStrategy {
    double calcularFrete();
}