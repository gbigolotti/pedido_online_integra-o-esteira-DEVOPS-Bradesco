package com.seuprojeto;

import com.seuprojeto.pedido.Pedido;
import com.seuprojeto.pedido.PedidoBuilder;
import com.seuprojeto.frete.CorreiosFrete;
import com.seuprojeto.pagamento.PagamentoFacade;

public class Main {
    public static void main(String[] args) {
        Pedido pedido = new PedidoBuilder()
                .comProduto("Notebook")
                .comQuantidade(1)
                .comValor(3500.0)
                .comFrete(new CorreiosFrete())
                .build();

        PagamentoFacade.processarPagamento(pedido);
        pedido.notificarCliente();
    }
}