package com.seuprojeto.pedido;

import com.seuprojeto.frete.FreteStrategy;
import com.seuprojeto.notificacao.EmailService;

public class Pedido {
    private String produto;
    private int quantidade;
    private double valor;
    private FreteStrategy frete;

    public Pedido(String produto, int quantidade, double valor, FreteStrategy frete) {
        this.produto = produto;
        this.quantidade = quantidade;
        this.valor = valor;
        this.frete = frete;
    }

    public void notificarCliente() {
        new EmailService().enviar("Seu pedido foi recebido!");
    }
}